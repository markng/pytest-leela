"""Data models for mutation testing."""

# NOTE: Do NOT add ``from __future__ import annotations`` here.
# On Python <=3.13, this lets an invalid ``BitOr -> BitAnd`` annotation
# mutation fail while the definition is executed. Python 3.14 uses PEP 649
# lazy annotations instead; the annotation-policy regression reads supported
# hints to exercise that failure. ``EnrichmentStats`` keeps its self-reference
# quoted because it is defined before the class name is bound.

from dataclasses import dataclass, field
from typing import Literal

MutantStatus = Literal["killed", "survived", "error"]


@dataclass
class EnrichmentStats:
    """Breakdown of how mutation points received their inferred type.

    ``from_annotations`` counts points whose type came from a parameter
    annotation, return-type annotation, or a literal constant in the operand.

    ``from_assignment_dataflow`` counts points whose type was resolved via the
    assignment environment — i.e. the type flowed from a local-variable
    assignment (``x = 5``, ``x: int = ...``) rather than from a declared
    parameter or return annotation.

    A single point is counted in exactly one bucket.  Points that received no
    type information are counted in neither.
    """

    from_annotations: int = 0
    from_assignment_dataflow: int = 0

    def __add__(self, other: "EnrichmentStats") -> "EnrichmentStats":
        return EnrichmentStats(
            from_annotations=self.from_annotations + other.from_annotations,
            from_assignment_dataflow=self.from_assignment_dataflow
            + other.from_assignment_dataflow,
        )


@dataclass(frozen=True)
class MutationPoint:
    """A location in source code where a mutation can be applied."""

    file_path: str
    module_name: str
    lineno: int
    col_offset: int
    node_type: str  # "BinOp", "Compare", "BoolOp", "UnaryOp", "Return"
    original_op: str  # "Add", "Lt", "And", "True", etc.
    inferred_type: str | None  # "int", "str", "bool", "Optional[int]", None


@dataclass(frozen=True)
class Mutant:
    """A specific mutation to apply."""

    point: MutationPoint
    replacement_op: str
    mutant_id: int


@dataclass
class MutantResult:
    """Result of testing a single mutant."""

    mutant: Mutant
    killed: bool
    tests_run: int
    killing_test: str | None  # Which test killed it
    time_seconds: float
    test_ids_run: list[str] = field(default_factory=list)  # all tests executed
    killing_tests: list[str] = field(default_factory=list)  # all failing tests
    # Why no trustworthy verdict was possible (crash, usage error, zero
    # tests, or inconclusive failure after zero or positive call counts).
    # Errors are excluded from the score; set only when ``killed`` is False.
    error: str | None = None

    def __post_init__(self) -> None:
        if self.killed and self.error is not None:
            raise ValueError(
                f"a killed mutant cannot also carry an error: {self.error!r}"
            )

    @property
    def status(self) -> MutantStatus:
        """``"killed"``, ``"survived"`` or ``"error"``."""
        if self.killed:
            return "killed"
        if self.error is not None:
            return "error"
        return "survived"


@dataclass
class CoverageMap:
    """Maps source lines to the tests that execute them."""

    line_to_tests: dict[tuple[str, int], set[str]] = field(default_factory=dict)
    test_times: dict[str, float] = field(default_factory=dict)

    def tests_for(self, file_path: str, lineno: int) -> set[str]:
        return self.line_to_tests.get((file_path, lineno), set())

    def add(self, file_path: str, lineno: int, test_id: str) -> None:
        key = (file_path, lineno)
        if key not in self.line_to_tests:
            self.line_to_tests[key] = set()
        self.line_to_tests[key].add(test_id)


@dataclass
class RunResult:
    """Complete result of a mutation testing run."""

    target_files: list[str]
    total_mutants: int
    mutants_tested: int
    mutants_pruned: int  # Removed by type analysis
    results: list[MutantResult]
    wall_time_seconds: float
    coverage_map: CoverageMap | None = None
    target_sources: dict[str, str] = field(default_factory=dict)  # file_path -> source
    enrichment_stats: EnrichmentStats = field(default_factory=EnrichmentStats)
    diff_base: str | None = None  # --diff ref that was active, or None for full run

    @property
    def killed(self) -> int:
        return sum(1 for r in self.results if r.killed)

    @property
    def survived(self) -> list[MutantResult]:
        return [r for r in self.results if r.status == "survived"]

    @property
    def errors(self) -> list[MutantResult]:
        """Mutants without a trustworthy verdict; never scored."""
        return [r for r in self.results if r.status == "error"]

    @property
    def mutants_scored(self) -> int:
        """Mutants with a real verdict (killed or survived)."""
        return self.mutants_tested - len(self.errors)

    @property
    def mutation_score(self) -> float:
        if self.mutants_scored == 0:
            return 0.0
        return self.killed / self.mutants_scored * 100.0


@dataclass(frozen=True)
class EngineProgress:
    """A single progress event emitted by the engine."""

    kind: str  # "symbol-start", "mutant", "done" (successful completion)
    file_path: str = ""
    lineno: int = 0
    op: str = ""
    status: str = ""  # mutant: "killed", "survived", "cache-hit", "error"
    symbol_id: str | None = None
    symbol_short: str = ""
    n_mutants_in_symbol: int = 0
    killing_test: str | None = None
    ordinal: int = 0
    total: int = 0
    selected_tests: int | None = None
    timeout_seconds: float | None = None
    elapsed_seconds: float = 0.0
    timed_out: bool = False
    phase: str = ""
